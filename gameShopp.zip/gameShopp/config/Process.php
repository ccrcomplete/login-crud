<?php

 
class Functions
{
   public function Login()
   {
      $user = $_POST['email'];
      $pass = $_POST['pass'];

      //instanciar el objeto
      $users = new DatabaseProcess();
      // llamado función de login
      $users->login($user, $pass);
      $response = $users->login($user, $pass);
      echo $response;

      if ($response === "True") {
         header("Location: ../view./home.php");
      } else {
         echo '<div class="alert alert-danger mt-2" role="alert">
                  Wrong email or password, please try again!
               </div>';
      }
   }

   public function AddGame()
   {
      $game_name = $_POST['game_name'];
      $game_description = $_POST['game_description'];
      $price = $_POST['price'];
      $creators = $_POST['creators'];
      $company = $_POST['company'];
      $public = $_POST['public'];

      $create = new DatabaseProcess();
      $response = $create->addGame($game_name, $game_description, $price, $creators, $company, $public);
      if ($response === "True") {
         echo '<div class="alert alert-success mt-2" role="alert">
                  Succesfully!
               </div>';
      } else {
         echo '<div class="alert alert-danger mt-2" role="alert">
                  Something wrong with the publish!
               </div>';
      }
   }

   function Games()
   {
      $list = new DatabaseProcess();
      $list -> getAllgames();
   }
}

?>




